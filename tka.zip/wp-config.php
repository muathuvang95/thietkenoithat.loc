<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'tka');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', 'utf8mb4_general_ci');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'r5rpz_:v;GP91M(2u r`6Hg1MG4$<,.Qp]-DI=h4i`xVHz7!bm-[;D{{i%WZy&#p');
define('SECURE_AUTH_KEY',  'q|w@ep?>v]$MUvdOHPRY[h!}!}.Zqj[)SGrqyVt|a/bw_mtX&Wl %A]}`#.j;>uM');
define('LOGGED_IN_KEY',    '`8.D^Ke{T[eZF: 7X&0bz]kp.6a%)QoeVs{?}~2vx]a@@riuOR*n]C+~.5?#<=5y');
define('NONCE_KEY',        'L$h/=u5;Q&n(alZ*=^F R+4:M:%3VFEX7D?<^i,%Cvo<W$S1E%qPcu{mAb8;Xp~9');
define('AUTH_SALT',        'K=14T:wJa[0p:,/kqde[&+Iq.H`4xF]7`hj._~GR[/Ts+J1BtNEG+aJ~63UP7Zp%');
define('SECURE_AUTH_SALT', '90aXe.>rg7n@&w50<G|U^?15uy*jIkG[M7c:ibx/,g=Q=n?KmwY,U3V[T<mSPH$F');
define('LOGGED_IN_SALT',   'xqkB|WC:h,L4rR?yqt-oCYr?`T#K10Ol_<~wVAMXzyo^uoJ.e<YDLdEq{M!A~{4F');
define('NONCE_SALT',       ';_n-cu& `3}Z8pWVc9!uAT(a?sb`C)76U`zdT@+aA:)*}qjMyI2FjQbZ& +e!-oC');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'vei_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
